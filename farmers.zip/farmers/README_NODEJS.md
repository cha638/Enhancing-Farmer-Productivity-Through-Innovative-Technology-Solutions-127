# 🌾 AgriTech Portal - Node.js Setup Guide

## 🚀 Quick Start (3 Steps)

### 1. Install Dependencies
```bash
cd farmers
npm install
```

### 2. Setup Database (Optional)
```bash
# Install MySQL (if not installed)
# Create database: agritech_portal
# Import: database.sql
```

### 3. Start Server
```bash
npm start
# OR for development with auto-reload:
npm run dev
```

## 📱 Access Portal
- **URL**: http://localhost:3000
- **Demo Login**: demo/demo
- **All Features**: Fully functional

## 🛠️ Installation Commands

### Windows:
```cmd
cd farmers
npm install
npm start
```

### Mac/Linux:
```bash
cd farmers
npm install
npm start
```

## 📊 Features Available
- ✅ **Soil Analysis API** - Real-time analysis with database storage
- ✅ **User Authentication** - Registration and login system
- ✅ **GPS Location Services** - Live location mapping
- ✅ **Excel Report Generation** - Downloadable crop reports
- ✅ **Government Schemes** - Scheme information and applications
- ✅ **Feedback System** - Farmer support and feedback
- ✅ **Database Integration** - MySQL with all tables
- ✅ **Mobile Responsive** - Works on all devices

## 🔧 Configuration

### Database Setup (Optional):
1. Install MySQL
2. Create database: `agritech_portal`
3. Import `database.sql`
4. Update `.env` file with credentials

### Without Database:
- Project works with demo data
- All frontend features functional
- API endpoints return mock data

## 📁 Project Structure
```
farmers/
├── server.js              ← Node.js server
├── package.json           ← Dependencies
├── .env                   ← Configuration
├── home.html             ← Main entry point
├── dashboard.html        ← Dashboard
├── live_map.html         ← GPS mapping
├── crop_fertilizer_report.html ← Excel reports
├── paddy_soil_sensor.html ← Soil analysis
├── schemes.html          ← Government schemes
├── feedback.html         ← Feedback system
└── database.sql          ← Database schema
```

## 🌐 API Endpoints
- `POST /api/register` - Farmer registration
- `POST /api/login` - User authentication
- `POST /api/soil-analysis` - Soil analysis
- `POST /api/feedback` - Feedback submission
- `GET /api/dashboard/:id` - Dashboard data

## 🎯 Demo Access
- **Username**: demo
- **Password**: demo
- **Features**: All features work with demo data

## 📞 Support
- **Issues**: Check console for errors
- **Database**: Optional - works without MySQL
- **Port**: Default 3000 (configurable in .env)

## 🚀 Production Deployment
1. Set `NODE_ENV=production` in .env
2. Update database credentials
3. Change JWT_SECRET
4. Deploy to cloud platform (Heroku, AWS, etc.)

---
**🌾 AgriTech Portal - Ready to run with Node.js!**