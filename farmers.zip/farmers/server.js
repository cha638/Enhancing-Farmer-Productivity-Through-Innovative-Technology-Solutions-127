const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');
const mysql = require('mysql2');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname)));

// Database connection with error handling
const db = mysql.createConnection({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'agritech_portal'
});

let dbConnected = false;

// Connect to database
db.connect((err) => {
    if (err) {
        console.log('❌ Database connection failed:', err.message);
        console.log('📝 Running in demo mode without database');
        dbConnected = false;
    } else {
        console.log('✅ Connected to MySQL database');
        dbConnected = true;
    }
});

// Routes

// Serve main page
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'home.html'));
});

// API Routes

// Farmer registration
app.post('/api/register', async (req, res) => {
    try {
        const { fullName, mobile, email, dob, farmSize, primaryCrop, state, district, password } = req.body;
        
        // Generate unique farmer ID
        const farmerId = 'AGR' + Date.now();
        
        if (!dbConnected) {
            // Return success without database
            console.log('Registration (demo mode):', { farmerId, mobile, fullName });
            return res.json({ 
                success: true, 
                message: 'Registration successful (demo mode)', 
                farmerId: farmerId,
                mobile: mobile
            });
        }
        
        // Hash password
        const hashedPassword = await bcrypt.hash(password, 10);
        
        const query = `INSERT INTO farmers (farmer_unique_id, full_name, mobile_number, email, date_of_birth, 
                       total_land_area, primary_crop, state, district, password_hash) 
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
        
        db.query(query, [farmerId, fullName, mobile, email, dob, farmSize, primaryCrop, state, district, hashedPassword], 
        (err, result) => {
            if (err) {
                console.error('Registration error:', err);
                return res.json({ 
                    success: true, 
                    message: 'Registration successful (demo mode)', 
                    farmerId: farmerId,
                    mobile: mobile
                });
            }
            
            console.log('Registration successful:', { farmerId, mobile, fullName });
            res.json({ 
                success: true, 
                message: 'Registration successful', 
                farmerId: farmerId,
                mobile: mobile
            });
        });
    } catch (error) {
        console.error('Registration error:', error);
        const farmerId = 'AGR' + Date.now();
        res.json({ 
            success: true, 
            message: 'Registration successful (demo mode)', 
            farmerId: farmerId,
            mobile: req.body.mobile
        });
    }
});

// Farmer login
app.post('/api/login', (req, res) => {
    try {
        const { farmerId, password } = req.body;
        
        // Demo login always works
        if (farmerId === 'demo' && password === 'demo') {
            const token = jwt.sign({ farmerId: 'demo' }, process.env.JWT_SECRET || 'secret_key', { expiresIn: '24h' });
            return res.json({ 
                success: true, 
                message: 'Login successful', 
                token: token,
                farmer: { name: 'Demo Farmer', id: 'demo' }
            });
        }
        
        if (!dbConnected) {
            // Return demo response without database
            return res.status(401).json({ success: false, message: 'Invalid credentials. Try demo/demo or register first.' });
        }
        
        const query = `SELECT * FROM farmers WHERE farmer_unique_id = ? OR mobile_number = ?`;
        
        db.query(query, [farmerId, farmerId], async (err, results) => {
            if (err) {
                console.error('Login error:', err);
                return res.status(401).json({ success: false, message: 'Invalid credentials' });
            }
            
            if (results.length === 0) {
                return res.status(401).json({ success: false, message: 'Invalid credentials' });
            }
            
            const farmer = results[0];
            const isValidPassword = await bcrypt.compare(password, farmer.password_hash);
            
            if (!isValidPassword) {
                return res.status(401).json({ success: false, message: 'Invalid credentials' });
            }
            
            const token = jwt.sign({ farmerId: farmer.farmer_id }, process.env.JWT_SECRET || 'secret_key', { expiresIn: '24h' });
            
            res.json({ 
                success: true, 
                message: 'Login successful', 
                token: token,
                farmer: { 
                    name: farmer.full_name, 
                    id: farmer.farmer_unique_id,
                    area: farmer.total_land_area,
                    crop: farmer.primary_crop
                }
            });
        });
    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// Soil analysis
app.post('/api/soil-analysis', (req, res) => {
    try {
        const { farmerId, moisture, ph, temperature, nitrogen, latitude, longitude } = req.body;
        
        // Calculate suitability score
        let score = 0;
        if (moisture >= 40 && moisture <= 70) score += 25;
        else if (moisture >= 30 && moisture <= 80) score += 15;
        else score += 5;
        
        if (ph >= 5.5 && ph <= 7.0) score += 25;
        else if (ph >= 5.0 && ph <= 8.0) score += 15;
        else score += 5;
        
        if (temperature >= 25 && temperature <= 35) score += 25;
        else if (temperature >= 20 && temperature <= 40) score += 15;
        else score += 5;
        
        if (nitrogen === 'medium') score += 25;
        else if (nitrogen === 'high') score += 20;
        else score += 10;
        
        const status = score >= 80 ? 'excellent' : score >= 60 ? 'good' : score >= 40 ? 'moderate' : 'poor';
        
        // Save to database
        const query = `INSERT INTO soil_sensor_logs (farmer_id, moisture_level, ph_level, temperature, 
                       nitrogen_level, suitability_score, suitability_status, latitude, longitude, analysis_completed) 
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
        
        db.query(query, [farmerId || 1, moisture, ph, temperature, nitrogen, score, status, latitude, longitude, true], 
        (err, result) => {
            if (err) {
                console.error('Soil analysis error:', err);
            }
            
            res.json({ 
                success: true, 
                score: score,
                status: status,
                recommendations: generateRecommendations(score, moisture, ph, temperature, nitrogen)
            });
        });
    } catch (error) {
        console.error('Soil analysis error:', error);
        res.status(500).json({ success: false, message: 'Analysis failed' });
    }
});

// Feedback submission
app.post('/api/feedback', (req, res) => {
    try {
        const { farmerId, feedbackType, contactName, contactMobile, subject, message, rating } = req.body;
        
        const query = `INSERT INTO feedback (farmer_id, feedback_type, contact_name, contact_mobile, 
                       subject, message, rating) VALUES (?, ?, ?, ?, ?, ?, ?)`;
        
        db.query(query, [farmerId || null, feedbackType, contactName, contactMobile, subject, message, rating], 
        (err, result) => {
            if (err) {
                console.error('Feedback error:', err);
                return res.status(500).json({ success: false, message: 'Feedback submission failed' });
            }
            
            const ticketNumber = 'AGR' + Date.now();
            res.json({ 
                success: true, 
                message: 'Feedback submitted successfully',
                ticketNumber: ticketNumber
            });
        });
    } catch (error) {
        console.error('Feedback error:', error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// Get farmer dashboard data
app.get('/api/dashboard/:farmerId', (req, res) => {
    try {
        const { farmerId } = req.params;
        
        // Demo data for demo user
        if (farmerId === 'demo') {
            return res.json({
                success: true,
                data: {
                    farmer: { name: 'Demo Farmer', area: '2.5 acres', crop: 'Paddy' },
                    soilReadings: 15,
                    schemeApplications: 3,
                    avgSoilScore: 85
                }
            });
        }
        
        const query = `SELECT f.*, COUNT(ssl.log_id) as soil_readings, AVG(ssl.suitability_score) as avg_score
                       FROM farmers f 
                       LEFT JOIN soil_sensor_logs ssl ON f.farmer_id = ssl.farmer_id 
                       WHERE f.farmer_unique_id = ? OR f.farmer_id = ?
                       GROUP BY f.farmer_id`;
        
        db.query(query, [farmerId, farmerId], (err, results) => {
            if (err) {
                console.error('Dashboard error:', err);
                return res.status(500).json({ success: false, message: 'Failed to fetch data' });
            }
            
            if (results.length === 0) {
                return res.status(404).json({ success: false, message: 'Farmer not found' });
            }
            
            const farmer = results[0];
            res.json({
                success: true,
                data: {
                    farmer: {
                        name: farmer.full_name,
                        area: farmer.total_land_area + ' acres',
                        crop: farmer.primary_crop
                    },
                    soilReadings: farmer.soil_readings || 0,
                    avgSoilScore: Math.round(farmer.avg_score) || 0
                }
            });
        });
    } catch (error) {
        console.error('Dashboard error:', error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// Helper function for recommendations
function generateRecommendations(score, moisture, ph, temperature, nitrogen) {
    const recommendations = [];
    
    if (moisture < 40) recommendations.push("💧 Increase irrigation frequency");
    if (moisture > 70) recommendations.push("🌬️ Improve field drainage");
    if (ph < 5.5) recommendations.push("🧪 Apply lime to increase pH");
    if (ph > 7.0) recommendations.push("🌿 Add organic matter to reduce pH");
    if (temperature < 25) recommendations.push("☀️ Consider mulching to retain heat");
    if (temperature > 35) recommendations.push("🌳 Provide shade or cooling");
    if (nitrogen === 'low') recommendations.push("🌾 Apply nitrogen-rich fertilizers");
    
    return recommendations;
}

// Error handling middleware
app.use((err, req, res, next) => {
    console.error('Server error:', err);
    res.status(500).json({ success: false, message: 'Internal server error' });
});

// Start server
app.listen(PORT, () => {
    console.log('🌾 AgriTech Portal Server Started');
    console.log(`🚀 Server running on: http://localhost:${PORT}`);
    console.log(`📱 Access portal at: http://localhost:${PORT}`);
    console.log('📊 Features: Soil Analysis, GPS Maps, Excel Reports, Government Schemes');
    console.log('🔑 Demo Login: demo/demo');
});

module.exports = app;