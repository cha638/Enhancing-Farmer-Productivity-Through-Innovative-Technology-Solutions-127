-- ====================================================
-- AgriTech Portal Database Schema
-- Enhancing Farmer Productivity Through Technology
-- ====================================================
-- 
-- This database is designed for future backend integration
-- with IoT sensors, mobile applications, and AI analytics
-- 
-- Created for: Academic Project Submission
-- Technology: MySQL Database
-- ====================================================

-- Create Database
CREATE DATABASE IF NOT EXISTS agritech_portal;
USE agritech_portal;

-- ====================================================
-- 1. USER MANAGEMENT TABLES
-- ====================================================

-- Farmers Registration Table
CREATE TABLE farmers (
    farmer_id INT PRIMARY KEY AUTO_INCREMENT,
    farmer_unique_id VARCHAR(20) UNIQUE NOT NULL, -- Government issued farmer ID
    full_name VARCHAR(100) NOT NULL,
    mobile_number VARCHAR(15) UNIQUE NOT NULL,
    email VARCHAR(100),
    date_of_birth DATE,
    aadhaar_number VARCHAR(12) UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    profile_image VARCHAR(255),
    
    -- Address Information
    state VARCHAR(50) NOT NULL,
    district VARCHAR(50) NOT NULL,
    tehsil VARCHAR(50),
    village VARCHAR(50),
    pincode VARCHAR(10),
    
    -- Farm Information
    total_land_area DECIMAL(10,2), -- in acres
    irrigated_area DECIMAL(10,2),
    primary_crop VARCHAR(50),
    farming_experience INT, -- years
    
    -- Account Status
    is_verified BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,
    registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP,
    
    -- Government Scheme Integration
    pm_kisan_enrolled BOOLEAN DEFAULT FALSE,
    soil_health_card_number VARCHAR(20),
    
    INDEX idx_mobile (mobile_number),
    INDEX idx_state_district (state, district),
    INDEX idx_primary_crop (primary_crop)
);

-- Admin Users Table
CREATE TABLE admin_users (
    admin_id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('super_admin', 'state_admin', 'district_admin', 'block_admin') NOT NULL,
    assigned_region VARCHAR(100), -- state/district/block name
    is_active BOOLEAN DEFAULT TRUE,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP
);

-- ====================================================
-- 2. CROP MANAGEMENT TABLES
-- ====================================================

-- Crop Master Data
CREATE TABLE crops (
    crop_id INT PRIMARY KEY AUTO_INCREMENT,
    crop_name VARCHAR(50) NOT NULL,
    crop_type ENUM('kharif', 'rabi', 'zaid', 'perennial') NOT NULL,
    scientific_name VARCHAR(100),
    optimal_temperature_min INT, -- Celsius
    optimal_temperature_max INT,
    optimal_ph_min DECIMAL(3,1),
    optimal_ph_max DECIMAL(3,1),
    water_requirement VARCHAR(50), -- High/Medium/Low
    growing_season_days INT,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Farmer Crop Planning
CREATE TABLE farmer_crops (
    plan_id INT PRIMARY KEY AUTO_INCREMENT,
    farmer_id INT NOT NULL,
    crop_id INT NOT NULL,
    season ENUM('kharif', 'rabi', 'zaid') NOT NULL,
    year YEAR NOT NULL,
    area_planted DECIMAL(10,2), -- acres
    expected_yield DECIMAL(10,2), -- quintals
    actual_yield DECIMAL(10,2),
    sowing_date DATE,
    harvest_date DATE,
    status ENUM('planned', 'sown', 'growing', 'harvested', 'sold') DEFAULT 'planned',
    
    FOREIGN KEY (farmer_id) REFERENCES farmers(farmer_id) ON DELETE CASCADE,
    FOREIGN KEY (crop_id) REFERENCES crops(crop_id),
    INDEX idx_farmer_season (farmer_id, season, year)
);

-- ====================================================
-- 3. SMART SOIL SENSOR SYSTEM
-- ====================================================

-- IoT Soil Sensor Logs (Main Feature)
CREATE TABLE soil_sensor_logs (
    log_id INT PRIMARY KEY AUTO_INCREMENT,
    farmer_id INT NOT NULL,
    sensor_device_id VARCHAR(50), -- IoT device identifier
    
    -- Soil Parameters
    moisture_level DECIMAL(5,2) NOT NULL, -- percentage (0-100)
    ph_level DECIMAL(3,1) NOT NULL, -- pH scale (0-14)
    temperature DECIMAL(5,2) NOT NULL, -- Celsius
    nitrogen_level ENUM('low', 'medium', 'high') NOT NULL,
    phosphorus_level DECIMAL(8,2), -- ppm
    potassium_level DECIMAL(8,2), -- ppm
    
    -- Analysis Results
    suitability_score INT, -- 0-100
    suitability_status ENUM('excellent', 'good', 'moderate', 'poor') NOT NULL,
    recommendations TEXT, -- JSON format recommendations
    
    -- Location & Timing
    field_location VARCHAR(100),
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    reading_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- System Fields
    analysis_completed BOOLEAN DEFAULT FALSE,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (farmer_id) REFERENCES farmers(farmer_id) ON DELETE CASCADE,
    INDEX idx_farmer_date (farmer_id, reading_timestamp),
    INDEX idx_suitability (suitability_status)
);

-- Soil Sensor Devices
CREATE TABLE soil_sensors (
    sensor_id INT PRIMARY KEY AUTO_INCREMENT,
    device_id VARCHAR(50) UNIQUE NOT NULL,
    farmer_id INT NOT NULL,
    sensor_type VARCHAR(50), -- NPK, pH, Moisture, Temperature
    installation_date DATE,
    last_calibration DATE,
    battery_level INT, -- percentage
    status ENUM('active', 'inactive', 'maintenance') DEFAULT 'active',
    field_location VARCHAR(100),
    
    FOREIGN KEY (farmer_id) REFERENCES farmers(farmer_id) ON DELETE CASCADE
);

-- ====================================================
-- 4. GOVERNMENT SCHEMES & SUBSIDIES
-- ====================================================

-- Government Schemes Master
CREATE TABLE government_schemes (
    scheme_id INT PRIMARY KEY AUTO_INCREMENT,
    scheme_name VARCHAR(100) NOT NULL,
    scheme_code VARCHAR(20) UNIQUE,
    scheme_type ENUM('subsidy', 'insurance', 'loan', 'direct_benefit') NOT NULL,
    description TEXT,
    eligibility_criteria TEXT,
    benefit_amount DECIMAL(12,2),
    application_start_date DATE,
    application_end_date DATE,
    is_active BOOLEAN DEFAULT TRUE,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Farmer Scheme Applications
CREATE TABLE scheme_applications (
    application_id INT PRIMARY KEY AUTO_INCREMENT,
    farmer_id INT NOT NULL,
    scheme_id INT NOT NULL,
    application_number VARCHAR(50) UNIQUE,
    application_date DATE NOT NULL,
    status ENUM('submitted', 'under_review', 'approved', 'rejected', 'disbursed') DEFAULT 'submitted',
    applied_amount DECIMAL(12,2),
    approved_amount DECIMAL(12,2),
    disbursement_date DATE,
    remarks TEXT,
    
    FOREIGN KEY (farmer_id) REFERENCES farmers(farmer_id) ON DELETE CASCADE,
    FOREIGN KEY (scheme_id) REFERENCES government_schemes(scheme_id),
    INDEX idx_farmer_scheme (farmer_id, scheme_id),
    INDEX idx_status (status)
);

-- ====================================================
-- 5. MARKET INTELLIGENCE & PRICING
-- ====================================================

-- Market Prices (MSP & Market Rates)
CREATE TABLE market_prices (
    price_id INT PRIMARY KEY AUTO_INCREMENT,
    crop_id INT NOT NULL,
    market_name VARCHAR(100),
    state VARCHAR(50),
    district VARCHAR(50),
    price_type ENUM('msp', 'market', 'wholesale', 'retail') NOT NULL,
    price_per_quintal DECIMAL(10,2) NOT NULL,
    price_date DATE NOT NULL,
    trend ENUM('up', 'down', 'stable') DEFAULT 'stable',
    
    FOREIGN KEY (crop_id) REFERENCES crops(crop_id),
    INDEX idx_crop_date (crop_id, price_date),
    INDEX idx_location (state, district)
);

-- ====================================================
-- 6. FEEDBACK & SUPPORT SYSTEM
-- ====================================================

-- Farmer Feedback
CREATE TABLE feedback (
    feedback_id INT PRIMARY KEY AUTO_INCREMENT,
    farmer_id INT,
    feedback_type ENUM('general', 'technical', 'scheme', 'complaint', 'suggestion') NOT NULL,
    subject VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    rating INT CHECK (rating >= 1 AND rating <= 5),
    
    -- Contact Information
    contact_name VARCHAR(100),
    contact_mobile VARCHAR(15),
    contact_email VARCHAR(100),
    
    -- Status Tracking
    status ENUM('new', 'in_progress', 'resolved', 'closed') DEFAULT 'new',
    priority ENUM('low', 'medium', 'high', 'urgent') DEFAULT 'medium',
    assigned_to INT, -- admin_user_id
    resolution_notes TEXT,
    
    -- Timestamps
    submitted_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    resolved_date TIMESTAMP,
    
    FOREIGN KEY (farmer_id) REFERENCES farmers(farmer_id) ON DELETE SET NULL,
    FOREIGN KEY (assigned_to) REFERENCES admin_users(admin_id) ON DELETE SET NULL,
    INDEX idx_status (status),
    INDEX idx_farmer (farmer_id)
);

-- ====================================================
-- 7. NOTIFICATIONS & ALERTS
-- ====================================================

-- System Notifications
CREATE TABLE notifications (
    notification_id INT PRIMARY KEY AUTO_INCREMENT,
    farmer_id INT,
    notification_type ENUM('weather', 'scheme', 'price', 'technical', 'general') NOT NULL,
    title VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    is_urgent BOOLEAN DEFAULT FALSE,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (farmer_id) REFERENCES farmers(farmer_id) ON DELETE CASCADE,
    INDEX idx_farmer_unread (farmer_id, is_read)
);

-- ====================================================
-- 8. SYSTEM LOGS & ANALYTICS
-- ====================================================

-- User Activity Logs
CREATE TABLE user_activity_logs (
    log_id INT PRIMARY KEY AUTO_INCREMENT,
    farmer_id INT,
    activity_type VARCHAR(50), -- login, logout, form_submit, page_view
    activity_description TEXT,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (farmer_id) REFERENCES farmers(farmer_id) ON DELETE SET NULL,
    INDEX idx_farmer_date (farmer_id, created_date)
);

-- ====================================================
-- 9. INSERT SAMPLE DATA FOR TESTING
-- ====================================================

-- Insert Sample Crops
INSERT INTO crops (crop_name, crop_type, optimal_temperature_min, optimal_temperature_max, optimal_ph_min, optimal_ph_max, water_requirement, growing_season_days) VALUES
('Paddy', 'kharif', 25, 35, 5.5, 7.0, 'High', 120),
('Cotton', 'kharif', 21, 30, 5.8, 8.0, 'Medium', 180),
('Wheat', 'rabi', 15, 25, 6.0, 7.5, 'Medium', 120),
('Sugarcane', 'perennial', 26, 32, 6.5, 7.5, 'High', 365),
('Maize', 'kharif', 21, 27, 5.5, 7.0, 'Medium', 90);

-- Insert Sample Government Schemes
INSERT INTO government_schemes (scheme_name, scheme_code, scheme_type, description, benefit_amount, is_active) VALUES
('PM-KISAN', 'PMKISAN2024', 'direct_benefit', 'Pradhan Mantri Kisan Samman Nidhi - Direct income support', 6000.00, TRUE),
('PMFBY', 'PMFBY2024', 'insurance', 'Pradhan Mantri Fasal Bima Yojana - Crop Insurance', 0.00, TRUE),
('Soil Health Card', 'SHC2024', 'subsidy', 'Free soil testing and nutrient management', 0.00, TRUE),
('Kisan Credit Card', 'KCC2024', 'loan', 'Agricultural credit facility', 300000.00, TRUE);

-- Insert Sample Market Prices
INSERT INTO market_prices (crop_id, market_name, state, district, price_type, price_per_quintal, price_date, trend) VALUES
(1, 'Delhi Mandi', 'Delhi', 'New Delhi', 'msp', 2183.00, CURDATE(), 'up'),
(2, 'Mumbai Cotton Market', 'Maharashtra', 'Mumbai', 'market', 6500.00, CURDATE(), 'stable'),
(3, 'Punjab Wheat Market', 'Punjab', 'Ludhiana', 'msp', 2275.00, CURDATE(), 'up');

-- ====================================================
-- 10. CREATE VIEWS FOR EASY DATA ACCESS
-- ====================================================

-- Farmer Dashboard Summary View
CREATE VIEW farmer_dashboard_summary AS
SELECT 
    f.farmer_id,
    f.full_name,
    f.total_land_area,
    f.primary_crop,
    COUNT(DISTINCT fc.plan_id) as total_crop_plans,
    COUNT(DISTINCT sa.application_id) as scheme_applications,
    COUNT(DISTINCT ssl.log_id) as soil_readings,
    AVG(ssl.suitability_score) as avg_soil_score
FROM farmers f
LEFT JOIN farmer_crops fc ON f.farmer_id = fc.farmer_id
LEFT JOIN scheme_applications sa ON f.farmer_id = sa.farmer_id
LEFT JOIN soil_sensor_logs ssl ON f.farmer_id = ssl.farmer_id
GROUP BY f.farmer_id;

-- Latest Soil Analysis View
CREATE VIEW latest_soil_analysis AS
SELECT 
    ssl.*,
    f.full_name as farmer_name,
    f.district,
    f.state
FROM soil_sensor_logs ssl
INNER JOIN farmers f ON ssl.farmer_id = f.farmer_id
WHERE ssl.reading_timestamp = (
    SELECT MAX(reading_timestamp) 
    FROM soil_sensor_logs ssl2 
    WHERE ssl2.farmer_id = ssl.farmer_id
);

-- ====================================================
-- 11. CREATE STORED PROCEDURES
-- ====================================================

-- Procedure to analyze soil compatibility
DELIMITER //
CREATE PROCEDURE AnalyzeSoilCompatibility(
    IN p_farmer_id INT,
    IN p_moisture DECIMAL(5,2),
    IN p_ph DECIMAL(3,1),
    IN p_temperature DECIMAL(5,2),
    IN p_nitrogen ENUM('low', 'medium', 'high')
)
BEGIN
    DECLARE v_score INT DEFAULT 0;
    DECLARE v_status VARCHAR(20);
    DECLARE v_recommendations TEXT;
    
    -- Calculate suitability score based on optimal ranges
    -- Moisture (40-70% optimal)
    IF p_moisture BETWEEN 40 AND 70 THEN
        SET v_score = v_score + 25;
    ELSEIF p_moisture BETWEEN 30 AND 80 THEN
        SET v_score = v_score + 15;
    ELSE
        SET v_score = v_score + 5;
    END IF;
    
    -- pH (5.5-7.0 optimal for paddy)
    IF p_ph BETWEEN 5.5 AND 7.0 THEN
        SET v_score = v_score + 25;
    ELSEIF p_ph BETWEEN 5.0 AND 8.0 THEN
        SET v_score = v_score + 15;
    ELSE
        SET v_score = v_score + 5;
    END IF;
    
    -- Temperature (25-35°C optimal)
    IF p_temperature BETWEEN 25 AND 35 THEN
        SET v_score = v_score + 25;
    ELSEIF p_temperature BETWEEN 20 AND 40 THEN
        SET v_score = v_score + 15;
    ELSE
        SET v_score = v_score + 5;
    END IF;
    
    -- Nitrogen
    IF p_nitrogen = 'medium' THEN
        SET v_score = v_score + 25;
    ELSEIF p_nitrogen = 'high' THEN
        SET v_score = v_score + 20;
    ELSE
        SET v_score = v_score + 10;
    END IF;
    
    -- Determine status
    IF v_score >= 80 THEN
        SET v_status = 'excellent';
    ELSEIF v_score >= 60 THEN
        SET v_status = 'good';
    ELSEIF v_score >= 40 THEN
        SET v_status = 'moderate';
    ELSE
        SET v_status = 'poor';
    END IF;
    
    -- Generate recommendations (simplified)
    SET v_recommendations = CONCAT('{"score":', v_score, ',"status":"', v_status, '"}');
    
    -- Insert the analysis result
    INSERT INTO soil_sensor_logs (
        farmer_id, moisture_level, ph_level, temperature, nitrogen_level,
        suitability_score, suitability_status, recommendations, analysis_completed
    ) VALUES (
        p_farmer_id, p_moisture, p_ph, p_temperature, p_nitrogen,
        v_score, v_status, v_recommendations, TRUE
    );
    
    SELECT v_score as score, v_status as status, v_recommendations as recommendations;
END //
DELIMITER ;

-- ====================================================
-- 12. CREATE INDEXES FOR PERFORMANCE
-- ====================================================

-- Additional indexes for better query performance
CREATE INDEX idx_soil_logs_farmer_date ON soil_sensor_logs(farmer_id, reading_timestamp DESC);
CREATE INDEX idx_feedback_status_date ON feedback(status, submitted_date DESC);
CREATE INDEX idx_notifications_farmer_unread ON notifications(farmer_id, is_read, created_date DESC);
CREATE INDEX idx_market_prices_crop_date ON market_prices(crop_id, price_date DESC);

-- ====================================================
-- END OF DATABASE SCHEMA
-- ====================================================

-- Database Summary:
-- • 12 Main Tables for comprehensive farm management
-- • IoT Soil Sensor Integration (Main Feature)
-- • Government Schemes & Subsidy Management
-- • Market Intelligence & Price Tracking
-- • Farmer Feedback & Support System
-- • User Activity Logging & Analytics
-- • Sample Data for Testing
-- • Optimized Views & Stored Procedures
-- • Performance Indexes
-- 
-- Future Integration Ready:
-- • Mobile App APIs
-- • IoT Device Connectivity
-- • AI/ML Analytics
-- • Real-time Notifications
-- • Government Portal Integration
-- ====================================================