# 🌾 AgriTech Portal - Navigation Guide

## 📋 Overview
The AgriTech Portal now features a **permanent left sidebar navigation** that provides easy access to all features and pages.

## 🚀 Getting Started

### Entry Points
1. **index.html** - Landing page with feature overview
2. **home.html** - Main portal with left sidebar navigation (recommended)

### How to Access
1. Open `index.html` in your browser
2. Click "Enter Portal" button
3. You'll be redirected to `home.html` with the full navigation sidebar

## 🎯 Navigation Structure

### Left Sidebar Menu

#### 🏠 Dashboard
- Main dashboard with overview of all features
- Quick access cards to major functionalities

#### 🌱 Crop Management
- **Paddy Management** - Complete paddy cultivation guide
- **Cotton Management** - Cotton farming techniques
- **Smart Soil Analysis** - AI-powered soil compatibility assessment

#### 📊 Location & Reports
- **Live Location Map** - GPS-based location tracking
- **Crop & Fertilizer Report** - Detailed crop analysis
- **Market Intelligence** - Real-time market prices and trends

#### 🏛️ Government Services
- **Schemes & Subsidies** - PM-KISAN, PMFBY, and more
- **Feedback & Support** - Submit feedback and complaints
- **Help Center** - FAQs and support documentation

#### 👤 Account
- **Login** - User authentication
- **Register** - New farmer registration

## 🎨 Features

### Permanent Sidebar
- Always visible on the left side
- 280px width
- Smooth hover effects
- Organized by categories
- Icon-based navigation

### Main Content Area
- Loads pages in an iframe
- Full-width content display (adjusted for sidebar)
- Seamless page transitions
- No page reload required

### Responsive Design
- Mobile-friendly interface
- Touch-optimized buttons
- Accessible navigation
- Government-compliant design

## 📱 Page Structure

```
index.html (Landing Page)
    ↓
home.html (Main Portal with Sidebar)
    ├── dashboard.html
    ├── paddy.html
    ├── cotton.html
    ├── paddy_soil_sensor.html
    ├── live_map.html
    ├── crop_fertilizer_report.html
    ├── market_intelligence_report.html
    ├── schemes.html
    ├── feedback.html
    ├── help_support.html
    ├── login.html
    └── register.html
```

## 🔧 Technical Details

### Sidebar Implementation
- Fixed position on the left
- CSS-based styling (no external CSS files)
- JavaScript for page loading
- Iframe-based content display

### Page Loading
- Uses iframe to load content
- Maintains navigation state
- Fast page transitions
- No full page reload

### Color Scheme
- Primary: Green (#2e7d32) - Agriculture theme
- Secondary: Orange (#ff6600) - Government branding
- Background: Light green gradient
- Sidebar: Dark green gradient

## 🎯 Usage Tips

1. **Start from home.html** for full navigation experience
2. **Click any menu item** to load that page in the main area
3. **Sidebar is always visible** - no need to toggle
4. **Hover effects** provide visual feedback
5. **Organized categories** make navigation intuitive

## 📞 Support

For any issues or questions:
- **Helpline**: 1800-XXX-XXXX (24/7)
- **Email**: support@agritech.gov.in
- **Feedback**: Use the Feedback & Support page

## 🏆 Key Benefits

✅ **Easy Navigation** - All pages accessible from one place
✅ **No Page Reload** - Smooth transitions between pages
✅ **Always Visible** - Sidebar permanently displayed
✅ **Organized Structure** - Logical grouping of features
✅ **Visual Feedback** - Hover effects and icons
✅ **Government Style** - Official design compliance

---

**© 2024 AgriTech Portal - Enhancing Farmer Productivity Through Innovative Technology Solutions**
